# app.py (starter code) — keeps everything in one folder (app.py + index.html)
import json
from pathlib import Path
from threading import Lock

from flask import Flask, jsonify, request, render_template

app = Flask(__name__)

PROFILE_PATH = Path(__file__).with_name("profile.json")
PROFILE_LOCK = Lock()


def _normalize_profile(file_data: dict) -> dict:
    first_name = (file_data.get("first_name") or "").strip()
    last_name = (file_data.get("last_name") or "").strip()
    full_name = (f"{first_name} {last_name}").strip()

    name = (file_data.get("name") or full_name or "Student").strip()
    school = (file_data.get("school") or file_data.get("school_name") or "").strip()

    try:
        savings = float(file_data.get("savings", 0))
    except Exception:
        savings = 0.0

    hobbies = file_data.get("hobbies")
    if not isinstance(hobbies, list):
        hobbies = []

    favorite_color = (file_data.get("favorite_color") or "slateblue").strip()
    city = (file_data.get("city") or "").strip()

    return {
        "name": name,
        "city": city,
        "school": school,
        "favorite_color": favorite_color,
        "hobbies": hobbies,
        "savings": savings,
    }


def _read_profile_file() -> dict:
    if not PROFILE_PATH.exists():
        return {}
    try:
        return json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_profile_file(file_data: dict) -> None:
    PROFILE_PATH.write_text(json.dumps(file_data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def load_profile() -> dict:
    file_data = _read_profile_file()
    if not isinstance(file_data, dict):
        file_data = {}
    return _normalize_profile(file_data)


def save_profile(current_profile: dict) -> None:
    file_data = _read_profile_file()
    if not isinstance(file_data, dict):
        file_data = {}

    file_data["name"] = current_profile.get("name", "Student")
    file_data["city"] = current_profile.get("city", "")
    file_data["school"] = current_profile.get("school", "")
    file_data["favorite_color"] = current_profile.get("favorite_color", "slateblue")
    file_data["hobbies"] = current_profile.get("hobbies", [])
    file_data["savings"] = float(current_profile.get("savings", 0))

    _write_profile_file(file_data)


# Your profile with savings (loaded from profile.json)
profile = load_profile()

ZAKAT_RATE = 0.025  # 2.5%

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/profile")
def get_profile():
    with PROFILE_LOCK:
        return jsonify(profile)

@app.route("/add-saving", methods=["POST"])
def add_saving():
    data = request.get_json(silent=True) or {}
    try:
        amount = float(data.get("amount", 0))
    except Exception:
        return jsonify({"error": "Amount must be a number"}), 400
    if amount <= 0:
        return jsonify({"error": "Amount must be positive"}), 400

    with PROFILE_LOCK:
        profile["savings"] = float(profile.get("savings", 0)) + amount
        save_profile(profile)
        return jsonify({"savings": round(profile["savings"], 2)})

@app.route("/zakat")
def calc_zakat():
    with PROFILE_LOCK:
        zakat = float(profile.get("savings", 0)) * ZAKAT_RATE
        return jsonify({"zakat": round(zakat, 2), "rate": ZAKAT_RATE})

if __name__ == "__main__":
    app.run(debug=True)
