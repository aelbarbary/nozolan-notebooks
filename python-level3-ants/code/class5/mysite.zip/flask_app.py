from flask import Flask, render_template
import json
from pathlib import Path

app = Flask(__name__)

BASE_DIR = Path(__file__).parent
PROFILE_PATH = BASE_DIR / "profile.json"


def load_profile():
    return json.loads(PROFILE_PATH.read_text(encoding="utf-8"))


@app.route("/")
def profile_page():
    profile = load_profile()
    return render_template("profile.html", profile=profile)


if __name__ == "__main__":
    app.run(debug=True)
